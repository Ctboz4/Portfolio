//The comments explaining the code is above what is being explained

import java.io.IOException;
import java.io.File;
import java.io.FileWriter;

import javax.swing.JOptionPane;

public class App{
    public static void main(String[] args) {
    
    //This creates the GUI to allow to user to input the password
    String userInput = JOptionPane.showInputDialog("Please enter the password you would like encrypted: ");
    //This is just getting the Key that you want to be able to encrypt your password
    int key = Integer.parseInt(JOptionPane.showInputDialog("Enter key value please: 1 - 9"));

    //This is calling the encrypted Method and uses the userinput and key values for the parameters
    String encryptedPassword = encrypted(userInput, key);
        //This part just shows the value now, dont forget the "null" is there because we dont have a specific window to open it on
    JOptionPane.showMessageDialog(null,"Encrypted text: " + encryptedPassword);
    

    saveFile(encryptedPassword);

    
}


public static String encrypted(String input, int key){

    //Stringbuilder is used so that we can change strings without using up more memory, this is helpful when we need to change a string multiple times like in the for loop up ahead
    StringBuilder encrypted = new StringBuilder();

    //This for loop is getting every character of the password
    for(int i = 0; i < input.length(); i++){
        char ch = input.charAt(i);
    

    //this only changes letters, anything else remains the same
    if(Character.isLetter(ch)){
        //This is an if else statement, the value after the "?" whis is 'a' is the true statement, the value after the : which is 'A' is the false statement
        //This is just getting us a base value to subtrtact from later in the program
        char base = Character.isLowerCase(ch) ? 'a' : 'A';

        /*first off the (char) is converting  the value back to a character, it must go up front to tell the program to take the result of everthing in front of it and convert it, it is using Typecast
         Then we are taking our letter that is inputed and subtracting the Base which is what we just got, then we are adding our key to allow it to shift correctly, remember, this program is tkaing our input and encoding it, so we want it to change
        the % 26 is keeping us in the Alphabet because there are only 26 letters in the alphabet
        Adding the base gets us from the position of the alphabet the to ASCII value, which is what gets us the letter
        */
        char shifted = (char) ((ch - base + key) % 26 + base);
        encrypted.append(shifted);
    } else {
        encrypted.append(ch);
    }
}
return encrypted.toString();

}


public static void saveFile(String encryptedPassword){
    /*
     The try- catch block is to make sure if anything goes wrong that we can explain what happend
     The "true" after the file name makes sure that nothing is overriden, if it wasnt there or if it was false then everytime it would overwrite whatever was there
     */
    try(FileWriter writer = new FileWriter("EncryptedPasswords.txt",true)){
        writer.write(encryptedPassword + "\n");
        JOptionPane.showMessageDialog(null, "Password Saved Succesfully");


    }
    //The e is a variable that holds the error code inside it, IOExeption is just getting the reason that the program stopped working, IO stands for input/output
    catch (IOException e){
        JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
    }

}

}