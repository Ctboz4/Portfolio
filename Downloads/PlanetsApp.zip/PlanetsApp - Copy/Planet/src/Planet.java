public class Planet {
    private String name;
    private String type;
    private String average_surface_temp;
    private String atmosphere_composition;

    private String diameter;
    private String radius;
    private String circumference;
    private String surface_area;
    private String volume;
    private String mass;
    private String density;
    private String surface_gravity;
    private String orbital_period;

    

    public Planet() {
        name = "";
        type = "";
        average_surface_temp = "";
        atmosphere_composition = "";

        diameter = "";
        radius = "";
        circumference = "";
        surface_area = "";
        volume = "";
        mass = "";
        density = "";
        surface_gravity = "";
        orbital_period = "";
    }

    public Planet(String Name, String Type, String Average_Surface_Temp, String Atmosphere_Composition, String Diameter, String Radius, String Circumference, String Surface_Area, String Volume, String Mass, String Density, String Surface_Gravity, String Orbital_Period) {
        name = Name;
        type = Type;
        average_surface_temp = Average_Surface_Temp;
        atmosphere_composition = Atmosphere_Composition;

        diameter = Diameter;
        radius = Radius;
        circumference = Circumference;
        surface_area = Surface_Area;
        volume = Volume;
        mass = Mass;
        density = Density;
        surface_gravity = Surface_Gravity;
        orbital_period = Orbital_Period;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getAverage_Surface_Temp() {
        return average_surface_temp;
    }

    public String getAtmosphere_Composition() {
        return atmosphere_composition;
    }

    public String getDiameter() {
        return diameter;
    }

    public String getRadius() {
        return radius;
    }

    public String getCircumference() {
        return circumference;
    }

    public String getSurface_Area() {
        return surface_area;
    }

    public String getVolume() {
        return volume;
    }

    public String getMass() {
        return mass;
    }

    public String getDensity() {
        return density;
    }   

    public String getSurface_Gravity() {
        return surface_gravity;
    }

    public String getOrbital_Period() {
        return orbital_period;
    }


    
}
