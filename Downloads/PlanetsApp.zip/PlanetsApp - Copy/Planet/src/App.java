import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.awt.Image;
public class App {
    public static void main(String[] args) throws IOException {

        


        //Frame info start
        JFrame frame = new JFrame("New Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,300);
        frame.setVisible(true);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

        JPanel panel = new JPanel(new GridLayout(2, 4));
        


        //button info 
        JButton earthButton = new JButton("Earth");
        earthButton.setHorizontalTextPosition(JButton.CENTER);
        earthButton.setVerticalTextPosition(JButton.BOTTOM);
        JButton marsButton = new JButton("Mars");
        JButton mercuryButton = new JButton("Mercury");
        JButton venusButton = new JButton("Venus");
        JButton jupiterButton = new JButton("Jupiter");
        JButton saturnButton = new JButton("Saturn");
        JButton uranusButton = new JButton("Uranus");
        JButton neptuneButton = new JButton("Neptune");
        
        panel.add(earthButton);
        panel.add(marsButton);
        panel.add(mercuryButton);
        panel.add(venusButton);
        panel.add(jupiterButton);   
        panel.add(saturnButton);
        panel.add(uranusButton);
        panel.add(neptuneButton);

        frame.add(panel);

        frame.setVisible(true);

        
        Planet earth = new Planet("Earth", "Terrestrial", "15°C", "78% Nitrogen", "21", "1", "12742", "6371", "40075", "510100000", "1083206916846", "5972", "5514");
        Planet mars = new Planet("Mars", "Terrestrial", "-63°C", "95% Carbon Dioxide, 2.7% Nitrogen, 1.6% Argon", "6779", "3389", "21344", "144800000", "163115609799", "641710000000000000000000", "3934", "4", "687");
        Planet venus = new Planet("Venus", "Terrestrial", "464°C", "96.5% Carbon Dioxide, 3.5% Nitrogen", "12104", "6052", "38025", "460200000", "928415345893", "4867000000000000000000000", "5240", "9", "225");
        Planet mercury = new Planet("Mercury", "Terrestrial", "167°C", "Trace amounts of Oxygen, Sodium, Hydrogen, Helium, and Potassium", "4879", "2440", "15329", "74800000", "60830000000", "330110000000000000000000", "5430", "4", "88");
        Planet saturn = new Planet("Saturn", "Gas Giant", "-140°C", "96% Hydrogen, 3% Helium", "120536", "60268", "378675", "42700000000", "827129915150897", "568000000000000000000000", "687", "10.4", "10759");
        Planet uranus = new Planet("Uranus", "Ice Giant", "-195°C", "83% Hydrogen, 15% Helium, 2% Methane", "50724", "25362", "159354", "8083000000", "68330000000000", "86800000000000000000000", "1270", "8.7", "30687");
        Planet neptune = new Planet("Neptune", "Ice Giant", "-200°C", "80% Hydrogen, 19% Helium, 1% Methane", "49244", "24622", "154705", "7618000000", "62540000000000", "102000000000000000000000", "1638", "11.2", "60190");
        Planet jupiter = new Planet("Jupiter", "Gas Giant", "-108°C", "90% Hydrogen, 10% Helium", "139820", "69911", "142984", "778500000", "1.898 × 10^27", "1.43 × 10^15", "4333", "24.8", "779.8");



         // Add ActionListener for the Earth button
         earthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent v){
                ImageIcon earthIcon = new ImageIcon("Planet/Images/EarthSpinning.gif");
                String earthMessage = "Name: " + earth.getName()  + "\n" + 
                "Type: " + earth.getType() + "\n" +
                "Average Surface Temp: " + earth.getAverage_Surface_Temp() + "\n" +
                "Atmosphere Composition: " + earth.getAtmosphere_Composition() + "\n" +
                "Diameter: " + earth.getDiameter() + "\n" +
                "Radius: " + earth.getRadius() + " km\n" +
                "Circumference: " + earth.getCircumference() + " km\n" +
                "Surface Area: " + earth.getSurface_Area() + " km²\n" +
                "Volume: " + earth.getVolume() + " km³\n" +
                "Mass: " + earth.getMass() + " kg\n" +
                "Density: " + earth.getDensity() + " kg/m³\n" +
                "Surface Gravity: " + earth.getSurface_Gravity() + " m/s²\n" +
                "Orbital Period: " + earth.getOrbital_Period() + " days";




                JOptionPane.showMessageDialog(frame, 
                earthMessage, // Text to display
            "Earth Information", // Title of the dialog
            JOptionPane.INFORMATION_MESSAGE, // Message type
            earthIcon // Icon to display
                );
            }
        });

        marsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent v){
                ImageIcon marsIcon = new ImageIcon("Planet/Images/MarsSpinning.gif");
                String venusMessage = "Name: " + mars.getName()  + "\n" + 
                "Type: " + mars.getType() + "\n" +
                "Average Surface Temp: " + mars.getAverage_Surface_Temp() + "\n" +
                "Atmosphere Composition: " + mars.getAtmosphere_Composition() + "\n" +
                "Diameter: " + mars.getDiameter() + "\n" +
                "Radius: " + mars.getRadius() + " km\n" +
                "Circumference: " + mars.getCircumference() + " km\n" +
                "Surface Area: " + mars.getSurface_Area() + " km²\n" +
                "Volume: " + mars.getVolume() + " km³\n" +
                "Mass: " + mars.getMass() + " kg\n" +
                "Density: " + mars.getDensity() + " kg/m³\n" +
                "Surface Gravity: " + mars.getSurface_Gravity() + " m/s²\n" +
                "Orbital Period: " + mars.getOrbital_Period() + " days";




                JOptionPane.showMessageDialog(frame, 
                venusMessage, // Text to display
            "Mars Information", // Title of the dialog
            JOptionPane.INFORMATION_MESSAGE, // Message type
            marsIcon // Icon to display
                );
            }
        });

        mercuryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent v){
                ImageIcon mercuryIcon = new ImageIcon("Planet/Images/MercurySpinning.gif");
                String mercuryMessage = "Name: " + mercury.getName()  + "\n" + 
                "Type: " + mercury.getType() + "\n" +
                "Average Surface Temp: " + mercury.getAverage_Surface_Temp() + "\n" +
                "Atmosphere Composition: " + mercury.getAtmosphere_Composition() + "\n" +
                "Diameter: " + mercury.getDiameter() + "\n" +
                "Radius: " + mercury.getRadius() + " km\n" +
                "Circumference: " + mercury.getCircumference() + " km\n" +
                "Surface Area: " + mercury.getSurface_Area() + " km²\n" +
                "Volume: " + mercury.getVolume() + " km³\n" +
                "Mass: " + mercury.getMass() + " kg\n" +
                "Density: " + mercury.getDensity() + " kg/m³\n" +
                "Surface Gravity: " + mercury.getSurface_Gravity() + " m/s²\n" +
                "Orbital Period: " + mercury.getOrbital_Period() + " days";




                JOptionPane.showMessageDialog(frame, 
                mercuryMessage, // Text to display
            "Venus Information", // Title of the dialog
            JOptionPane.INFORMATION_MESSAGE, // Message type
            mercuryIcon // Icon to display
                );
            }
        });




        


        venusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent v){
                ImageIcon venusIcon = new ImageIcon("Planet/Images/VenusSpinning.gif");
                String venusMessage = "Name: " + venus.getName()  + "\n" + 
                "Type: " + venus.getType() + "\n" +
                "Average Surface Temp: " + venus.getAverage_Surface_Temp() + "\n" +
                "Atmosphere Composition: " + venus.getAtmosphere_Composition() + "\n" +
                "Diameter: " + venus.getDiameter() + "\n" +
                "Radius: " + venus.getRadius() + " km\n" +
                "Circumference: " + venus.getCircumference() + " km\n" +
                "Surface Area: " + venus.getSurface_Area() + " km²\n" +
                "Volume: " + venus.getVolume() + " km³\n" +
                "Mass: " + venus.getMass() + " kg\n" +
                "Density: " + venus.getDensity() + " kg/m³\n" +
                "Surface Gravity: " + venus.getSurface_Gravity() + " m/s²\n" +
                "Orbital Period: " + venus.getOrbital_Period() + " days";




                JOptionPane.showMessageDialog(frame, 
                venusMessage, // Text to display
            "Venus Information", // Title of the dialog
            JOptionPane.INFORMATION_MESSAGE, // Message type
            venusIcon // Icon to display
                );
            }
        });

        jupiterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent v){
                ImageIcon jupiterIcon = new ImageIcon("Planet/Images/JupiterSpinning.gif");
                String jupiterMessage = "Name: " + jupiter.getName()  + "\n" + 
                "Type: " + jupiter.getType() + "\n" +
                "Average Surface Temp: " + jupiter.getAverage_Surface_Temp() + "\n" +
                "Atmosphere Composition: " + jupiter.getAtmosphere_Composition() + "\n" +
                "Diameter: " + jupiter.getDiameter() + "\n" +
                "Radius: " + jupiter.getRadius() + " km\n" +
                "Circumference: " + jupiter.getCircumference() + " km\n" +
                "Surface Area: " + jupiter.getSurface_Area() + " km²\n" +
                "Volume: " + jupiter.getVolume() + " km³\n" +
                "Mass: " + jupiter.getMass() + " kg\n" +
                "Density: " + jupiter.getDensity() + " kg/m³\n" +
                "Surface Gravity: " + jupiter.getSurface_Gravity() + " m/s²\n" +
                "Orbital Period: " + jupiter.getOrbital_Period() + " days";




                JOptionPane.showMessageDialog(frame, 
                jupiterMessage, // Text to display
            "Venus Information", // Title of the dialog
            JOptionPane.INFORMATION_MESSAGE, // Message type
            jupiterIcon // Icon to display
                );
            }
        });

        saturnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent v){
                ImageIcon saturnIcon = new ImageIcon("Planet/Images/SaturnSpinning.gif");
                String saturnMessage = "Name: " + saturn.getName()  + "\n" + 
                "Type: " + saturn.getType() + "\n" +
                "Average Surface Temp: " + saturn.getAverage_Surface_Temp() + "\n" +
                "Atmosphere Composition: " + saturn.getAtmosphere_Composition() + "\n" +
                "Diameter: " + saturn.getDiameter() + "\n" +
                "Radius: " + saturn.getRadius() + " km\n" +
                "Circumference: " + saturn.getCircumference() + " km\n" +
                "Surface Area: " + saturn.getSurface_Area() + " km²\n" +
                "Volume: " + saturn.getVolume() + " km³\n" +
                "Mass: " + saturn.getMass() + " kg\n" +
                "Density: " + saturn.getDensity() + " kg/m³\n" +
                "Surface Gravity: " + saturn.getSurface_Gravity() + " m/s²\n" +
                "Orbital Period: " + saturn.getOrbital_Period() + " days";




                JOptionPane.showMessageDialog(frame, 
                saturnMessage, // Text to display
            "Saturn Information", // Title of the dialog
            JOptionPane.INFORMATION_MESSAGE, // Message type
            saturnIcon // Icon to display
                );
            }
        });

        uranusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent v){
                ImageIcon uranusIcon = new ImageIcon("Planet/Images/UranusSpin.gif");
                String uranusMessage = "Name: " + uranus.getName()  + "\n" + 
                "Type: " + uranus.getType() + "\n" +
                "Average Surface Temp: " + uranus.getAverage_Surface_Temp() + "\n" +
                "Atmosphere Composition: " + uranus.getAtmosphere_Composition() + "\n" +
                "Diameter: " + uranus.getDiameter() + "\n" +
                "Radius: " + uranus.getRadius() + " km\n" +
                "Circumference: " + uranus.getCircumference() + " km\n" +
                "Surface Area: " + uranus.getSurface_Area() + " km²\n" +
                "Volume: " + uranus.getVolume() + " km³\n" +
                "Mass: " + uranus.getMass() + " kg\n" +
                "Density: " + uranus.getDensity() + " kg/m³\n" +
                "Surface Gravity: " + uranus.getSurface_Gravity() + " m/s²\n" +
                "Orbital Period: " + uranus.getOrbital_Period() + " days";




                JOptionPane.showMessageDialog(frame, 
                uranusMessage, // Text to display
            "Saturn Information", // Title of the dialog
            JOptionPane.INFORMATION_MESSAGE, // Message type
            uranusIcon // Icon to display
                );
            }
        });

        neptuneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent v){
                ImageIcon neptunIcon = new ImageIcon("Planet/Images/NeptuneSpinning.gif");
                String neptunMessage = "Name: " + uranus.getName()  + "\n" + 
                "Type: " + neptune.getType() + "\n" +
                "Average Surface Temp: " + neptune.getAverage_Surface_Temp() + "\n" +
                "Atmosphere Composition: " + neptune.getAtmosphere_Composition() + "\n" +
                "Diameter: " + neptune.getDiameter() + "\n" +
                "Radius: " + neptune.getRadius() + " km\n" +
                "Circumference: " + neptune.getCircumference() + " km\n" +
                "Surface Area: " + neptune.getSurface_Area() + " km²\n" +
                "Volume: " + neptune.getVolume() + " km³\n" +
                "Mass: " + neptune.getMass() + " kg\n" +
                "Density: " + neptune.getDensity() + " kg/m³\n" +
                "Surface Gravity: " + neptune.getSurface_Gravity() + " m/s²\n" +
                "Orbital Period: " + neptune.getOrbital_Period() + " days";




                JOptionPane.showMessageDialog(frame, 
                neptunMessage, // Text to display
            "Saturn Information", // Title of the dialog
            JOptionPane.INFORMATION_MESSAGE, // Message type
            neptunIcon // Icon to display
                );
            }
        });

        



        

        
        
        
    }

    private static ImageIcon scaleImageIcon(String path, int width, int height) {
        ImageIcon icon = new ImageIcon(path);
        Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImage);
    }


}